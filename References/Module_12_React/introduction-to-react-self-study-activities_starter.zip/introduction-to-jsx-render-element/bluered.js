function main(x) {
  x = x + "he";
  return x;
}
function blue(x) {
  x = x + "ll";
  return x;
}
function red(x) {
  x = x + "o";
  return x;
}
console.log(main(""));
